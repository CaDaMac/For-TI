import javax.swing.JPanel;


public class StartUpScreen extends JPanel{
	
	
	
	

	public boolean isDone() {
		
		return false;
	}
	
	
	
	
	
}
